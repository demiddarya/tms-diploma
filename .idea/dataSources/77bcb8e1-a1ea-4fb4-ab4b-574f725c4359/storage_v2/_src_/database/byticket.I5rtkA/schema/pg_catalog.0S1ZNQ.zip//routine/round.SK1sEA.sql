create function round(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN round($1, 0);

comment on function round(numeric, unknown) is 'value rounded to ''scale'' of zero';

alter function round(numeric, unknown) owner to postgres;

